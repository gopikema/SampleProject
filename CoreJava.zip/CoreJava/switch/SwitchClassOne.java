class SwitchClassOne{
	
	public static void main(String[] gopi){
		int x = 8;
		switch(x)
		{
			case 4:
			System.out.println("Optum");
			break;
			
			case 0:
			System.out.println("UHG");
			
			case 8:
			System.out.println("UHC");
			default:
		}
	
	}
}