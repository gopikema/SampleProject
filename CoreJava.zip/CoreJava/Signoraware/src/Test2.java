
public class Test2 {
	
	private int number;
	private String str;

	public static void main(String[] args) {
		Test2 obj = new Test2();
		System.out.println(obj);

	}

	@Override
	public String toString() {
		return "number=" + number + ", str=" + str;
	}
}
