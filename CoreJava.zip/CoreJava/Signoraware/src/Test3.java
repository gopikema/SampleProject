class Test3
{
	int sno;
	String sname;
	String saddress;
	

	public Test3(int sno, String sname, String saddress) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.saddress = saddress;
	}
	public String toString(){
		return sno + ">" + sname + ">" + saddress;
	}
	public static void main(String[] args)
	{
		Test3 t1 = new Test3(101, "kosmik", "KPHB");
		Test3 t2 = new Test3(102, "Technologies", "Kukatpally");
		Test3 t3 = new Test3(102, "Naresh IT", "Ameerpet");
		
		System.out.println(t1);
		System.out.println(t2);
		System.out.println(t3);
	}
}