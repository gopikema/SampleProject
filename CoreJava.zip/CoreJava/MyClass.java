

class MyClass{
    public static void main(String[] args){
        System.out.println("hi");

    }
}



/*class MyClass{
    public static void main(String[] args){
		int x=8;
		if(x==8)
		{
			System.out.println("hi");
		}
		else
		{
			System.out.println("hello");
		}

    }
}*/