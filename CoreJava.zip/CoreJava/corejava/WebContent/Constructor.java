class Constrct
{
	int sno;
	String sname;
	String saddress;
	
	Constrct(int sno, String sname, String saddress)
	{
		this.sno = sno;
		this.sname = sname;
		this.saddress = saddress;
		
	}
	public string toString()
	{
		return "sno: " + sno + "sname: " + sname + "saddress: " + saddress
	}
}
