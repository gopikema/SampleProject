import java.io.File;
import java.io.IOException;

class TestFile{
	
	public static void main(String[] args) throws IOException
	{
		File f = new File("Optum.txt");
		System.out.println(f.exists());
		f.createNewFile();
		System.out.println(f.exists());
	}

}