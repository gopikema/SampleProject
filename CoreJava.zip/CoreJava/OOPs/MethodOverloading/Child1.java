class Kosmik
{
	public static void m1()
	{
		System.out.println("m1() Parent");
	}
}
class ChildCase extends Kosmik
{
	public static void m1()
	{
		System.out.println("m1() Child");
	}
	public static void main(String[] args)
	{
		System.out.println("w.r.t. parent class object");
		Kosmik p1 = new Kosmik();
		p1.m1();
		
		System.out.println("\n");
		
		System.out.println("w.r.t. child class object");
		Child ch1 = new Child();
		ch1.m1();
		
		System.out.println("\n");
		
		System.out.println("w.r.t. parent reference");
		Kosmik p2 = new Child();
		p2.m1();
	}
}