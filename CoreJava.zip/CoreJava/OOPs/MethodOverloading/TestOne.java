class Parent
{
	protected void m1(){
	 System.out.println("hi");
	}
}

class Child extends Parent{
	protected void m1(){
	System.out.println("hello");
	}
}
