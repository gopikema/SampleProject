class Sample
{
	public void m1();
	{
		System.out.println("hi");
	}
}
class Child extends Sample{
	
	public final void m1();
	{
	System.out.println("hello");
	}
	public static void main(String[] args){
	 Sample p1 = new Sample();
	 p1.m1();
	 Child p2 = new Child();
	 p2.m1();
	}
}