import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


class TestData
{
	public static void main(String[] args) throws IOException
	{
		File f1 = new File("C:\\Projects\\CoreJava\\OOPs\\VelocityDashers\\ApplicationList.txt");
		
		FileWriter fw = new FileWriter(f1);
		fw.write("DigitalCheckout");
		fw.write("MedicareMember");
	}
}