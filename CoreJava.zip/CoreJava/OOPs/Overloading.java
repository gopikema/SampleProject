class Test{
	public void m1(double x ){
	
	System.out.println("Hello world" + x);
	
	}
	public static void main(String[] args){

		Test t = new Test();
		t.m1('k');
		t.m1(100);
		t.m1(10.99f);
		t.m1(10.99);
	}

}