import java.io.File;
import java.io.IOException;

class NewFolder
{
	public static void main(String[] args) throws IOException
	{
		File f1 = new File("UHG");
		f1.mkdir();
		File f2 = new File("UHG", "optum.txt");
		f2.createNewFile();
	}
}