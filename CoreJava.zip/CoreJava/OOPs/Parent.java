class Parent{
  public void m1()
  {
  System.out.println(" Inside m1(): parent");
  }
	

	public class child extends Parent{
	
		public void m2()
		{
			System.out.println("Inside m2(): method");
		}
		public static void main(String[] args)
		{
			System.out.println("w.r.t. parent class object");
			
			Parent p1 = new Parent();
			p1.m1();
			//p1.m2();
			System.out.println("w.r.t. child class object");
			
			child.ch1 = new child();
			ch1.m1();
			//ch1.m2();
			
			System.out.println("\n");
		}
	}
	
}