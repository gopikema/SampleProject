import java.io.File;
import java.io.IOException;


class TaskFolder
{
	public static void main(String[] args) throws IOException
	{
		File f1 = new File("VelocityDashers");
		f1.mkdir();
		File f2 = new File("VelocityDashers", "ApplicationList.txt");
		f2.createNewFile();
		

	}
}