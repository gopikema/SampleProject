import java.io.Serializable;

class First{
	public class CustomerBean implements Serializable{
		
		private String firstname;
		private String lastname;
		private int age;
		private String location;
		
		public String getfirstname(){
			return firstname;
		}
		public void setfirstname(String firstname){
			this.firstname = firstname;
		}
		
		public String getlastname(){
			return lastname;
		}			
		public void setlastname(String lastname){
			this.lastname = lastname;
		}
		public int getage(){
			return age;
		}
		public void sgetage(int age){
			this.age = age;
		}
		
	}
}