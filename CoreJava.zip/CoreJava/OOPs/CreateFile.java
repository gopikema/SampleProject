import java.io.File;
import java.io.IOException;

class CreateFile
{
	public static void main(String[] args) throws IOException
	{
		File f = new File("UHG.txt");
		System.out.println(f.exists());
		f.createNewFile();
		System.out.println(f.exists());
	}
}