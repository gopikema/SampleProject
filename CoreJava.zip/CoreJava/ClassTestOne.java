
class ClassTestOne{
	public static void main(String[] args){
		boolean a= true;
		if(a)
		{
			System.out.println("Kosmik");
		}
		else
		{
			System.out.println("Java");
		}
	}
}