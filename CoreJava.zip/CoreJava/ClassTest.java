
class ClassTest{
	public static void main(String[] Gopi){
		int x=0;
		if(x==0)
		{
			System.out.println("Kosmik");
		}
		else
		{
			System.out.println("Java");
		}
	}
}