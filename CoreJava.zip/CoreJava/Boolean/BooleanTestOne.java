
class BooleanTestOne{
	public static void main(String[] args){
		boolean a= true;
		if(a=true)
		{
			System.out.println("Kosmik");
		}
		else
		{
			System.out.println("Java");
		}
	}
}