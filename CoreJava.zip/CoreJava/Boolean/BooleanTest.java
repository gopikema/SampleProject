
class BooleanTest{
	public static void main(String[] args){
		boolean a= true;
		if(a==false)
		{
			System.out.println("Kosmik");
		}
		else
		{
			System.out.println("Java");
		}
	}
}