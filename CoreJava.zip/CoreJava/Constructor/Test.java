class Test
{
	int sno;
	String sname;
	String saddress;
	
	Test(int sno, String sname, String saddress)
	{
		this.sno = sno;
		this.sname = sname;
		this.saddress = saddress;
		
		//Approach 1 >> //System.out.println(sno + ">" + sname + ">" + saddress);
		
	}
	public String toString(){
		return sno + ">" + sname + ">" + saddress;
	}
	public static void main(String[] args)
	{
		Test t1 = new Test(101, "kosmik", "KPHB");
		Test t2 = new Test(102, "Technologies", "Kukatpally");
		Test t3 = new Test(102, "Naresh IT", "Ameerpet");
		
		System.out.println(t1);
		System.out.println(t2);
	}
}