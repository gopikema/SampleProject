
class TestSampleTwo{
	public static void main(String[] args){
		String name = "Java";
		if(name=="JavaScript"){		
			System.out.println("Kosmik");
			System.out.println("Java");
			System.out.println("JavaScript");
			System.out.println("J2EE");
			System.out.println("JSEE");
		}
		else{
			System.out.println("Hello");
		}
		
	}
}