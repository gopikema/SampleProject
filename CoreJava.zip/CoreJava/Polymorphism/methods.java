class Parent{
	public void m1()  {
		System.out.println("hi");
	}
}
class Child extends Parent
{
	public void m1() {
		System.out.println("Hello");
	}
}