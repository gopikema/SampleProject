
class TestSample{
	public static void main(String[] args){
		boolean a = true;
		if(a==true)		
			System.out.println("Kosmik");
			System.out.println("Java");
			System.out.println("JavaScript");
			System.out.println("J2EE");
			System.out.println("JSEE");
		
	}
}