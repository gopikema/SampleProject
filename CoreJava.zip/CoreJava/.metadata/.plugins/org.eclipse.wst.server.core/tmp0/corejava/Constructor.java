class Test
{
	int sno;
	String sname;
	String saddress;
	
	Test(int sno, String sname, String saddress)
	{
		this.sno = sno;
		this.sname = sname;
		this.saddress = saddress;
		
	}
	public string toString()
	{
		return "sno: " + sno + "sname: " + sname + "saddress: " + saddress
	}
}
