class Test{
	public void m1(int x ){
	
	System.out.print.ln("Hello world" + x);
	
	}
	public static void main(String[] args){

		Test t = new Test();
		t.m1('k');
		t.m1(100);
	}

}